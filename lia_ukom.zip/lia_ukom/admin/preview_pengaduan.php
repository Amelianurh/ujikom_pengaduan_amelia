

<body id="page-top">

            <button type="button" class="btn btn-warning" onclick="frames['frame'].print();">
                <i class="fa fa-print"></i>
                Print    
</button>
        <iframe src="cetak_pengaduan.php" name="frame" width="100%"" height="600" frameborder="0"></iframe>

</body>
</html>

