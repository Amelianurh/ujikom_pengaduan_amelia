

<body id="page-top">


<div class="card shadow">
    <div class="card-header">
        Tulis Petugas
    </div>
    <div class="card-body">
        <form action="simpan_petugas.php" method="post" class="form-horizontal" enctype="multipart/form-data">
            <div class="form-group cols-sm-6">
                <label>Nama Petugas</label>
                <input type="text" name="nama_petugas" value="" class="form-control">
            </div>

            <div class="form-group cols-sm-6">
                <label>Username</label>
                <input type="text" name="username" value="" class="form-control">
            </div>

            <div class="form-group cols-sm-6">
                <label>Password</label>
                <input type="text" name="password" value="" class="form-control">
            </div>

            <div class="form-group cols-sm-6">
                <label>Telp</label>
                <input type="text" name="telp" value="" class="form-control">
            </div>

            <div class="form-group cols-sm-6">
                <label>Level</label>
                <select class="form-control" name="level">
                    <option>Pilih</option>
                    <option value="admin">Admin</option>
                    <option value="petugas">Petugas</option>
                </select>
            </div>

            <div class="form-group col-sm-6">
                <input type="submit" value="Simpan" class="btn btn-primary">
                <input type="reset" value="Kosongkan" class="btn btn-warning">
            </div>
        </form>

</body>

</html>
