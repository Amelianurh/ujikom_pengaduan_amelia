

<body id="page-top">


          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Data Petugas</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                   <tr> 
                        <th> ID Petugas</th>
                        <th>Nama Petugas</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Telp</th>
                        <th>Level</th>
                        <th>Aksi</th>

                   </tr>
                  </thead>
                <tfoot>

                  <?php
                  require '../koneksi.php';
                  $sql=mysqli_query($koneksi, "SELECT * FROM petugas");
                  while ($data=mysqli_fetch_array($sql)){

                  ?>
                  
                  <tbody>
                    <tr>
                     
                      <td><?php echo $data['id_petugas']; ?></td>
                      <td><?php echo $data['nama_petugas']; ?></td>
                      <td><?php echo $data['username']; ?></td>
                      <td><?php echo $data['password']; ?></td>
                      <td><?php echo $data['telp']; ?></td>
                      <td><?php echo $data['level']; ?></td>



                    <a href="?url=detail_pengaduan&id=<?php echo $data ['id_pengaduan'];?>" class="btn btn-info btn-icon-split">
                    <span class="icon text-white-50">
                   <i class="fas fa-check"></i>
                    </span>
                    <span class="text">Detail & Verifikasi</span>
                  </a>
                    
 



                      </td>
                    </tr>
       
                  </tbody>
                  <?php }?>
                </table>
          </div>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Ujikom SMK SANGKURIANG 1 CIMAHI 2023</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    <!-- End of Content Wrapper -->

  
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


</body>

</html>
